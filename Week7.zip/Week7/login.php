<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="container">
		<h1>Login Page</h1>
		<?php if(isset($_GET['status']) && $_GET['status']=='failed') { ?>
        <p style="color:red">Wrong Email or Password</p>
		<?php } ?>
		<form method="POST" action="verify.php">
			<label for="email">Email:</label>
			<input type="email" id="email" name="email" placeholder="Enter your email" required>
			<label for="password">Password:</label>
			<input type="password" id="password" name="password" placeholder="Enter your password" required>
            <p class="not-registered">Not registered yet? <a href="signup.php">Register</a></p>

			<input type="submit" value="Submit">
		</form>
	</div>
</body>
</html>

<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

include 'connection.php';

$conn = mysqli_connect($host, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$email = $_SESSION['email'];
$sql = "SELECT name FROM registration WHERE email='$email'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$name = $row['name'];

mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
    <style>
                body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        h1 {
            font-size: 3em;
            text-align: center;
            margin-top: 50px;
        }

        a {
            display: block;
            width: 200px;
            margin: 0 auto;
            padding: 10px;
            text-align: center;
            background-color: #3498db;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);
        }

        a:hover {
            background-color: #2980b9;
        }
</style>
</head>
<body>
	<h1>Welcome to <?php echo $name; ?></h1>
	<a href="logout.php">Logout</a>
</body>
</html>

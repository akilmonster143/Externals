<!DOCTYPE html>
<html>
<head>
  <title>File Upload and Display Example</title>
</head>
<body>
  <h2>File Upload</h2>
  <form action="" method="POST" enctype="multipart/form-data">
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload File" name="submit">
  </form>

  <h2>Uploaded File Contents</h2>
  <?php
  if (isset($_POST["submit"])) {
    if ($_FILES["fileToUpload"]["error"] === UPLOAD_ERR_OK) {
      $file = $_FILES["fileToUpload"]["tmp_name"];
      $fileContent = file_get_contents($file);

      echo "<pre>" . htmlspecialchars($fileContent) . "</pre>";
    } else {
      echo "Error uploading the file.";
    }
  }
  ?>
</body>
</html>

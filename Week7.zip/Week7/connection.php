<?php
$host = "localhost";
$username = "Akil";
$password = "Akilamu@321";
$database = "login_page";
?>

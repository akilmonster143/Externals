<!DOCTYPE html>
<html>
<head>
	<title>Signup Page</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
	<h1>Signup Here</h1>
	<form method="POST" action="sucess.php">
		<label for="name">Name:</label>
		<input type="text" id="name" name="name" placeholder="Enter your name" required>

		<label for="year">Year:</label>
		<input type="number" id="year" name="year" placeholder="Enter your year" required>

		<label for="email">Email:</label>
		<input type="email" id="email" name="email" placeholder="Enter your email" required>

		<label for="phone">Phone Number:</label>
		<input type="tel" id="phone" name="phone" placeholder="Enter your phone number" required>

		<label for="password">Password:</label>
		<input type="password" id="password" name="password" placeholder="Enter your password" required>

		<label for="confirm_password">Confirm Password:</label>
		<input type="password" id="cpassword" name="cpassword" placeholder="Enter your password again" required>

		<input type="submit" value="Submit">
	</form>
</body>
</html>
